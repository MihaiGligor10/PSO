#pragma once

#include "network.h"

void
DumpNetworkDevice(
    IN      PNETWORK_DEVICE_INFO        NetworkDevice
    );