#pragma once

void
ExSystemTimerTick(
    void
    );
