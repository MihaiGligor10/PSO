#pragma once

void
DumpIoApic(
    IN      PVOID       IoApicBaseAddress
    );