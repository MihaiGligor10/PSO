#pragma once

#include "cmos.h"

void
DumpCmos(
    IN      PCMOS_DATA      CmosData
    );