#pragma once

#include "mdl.h"

void
DumpMdl(
    IN      PMDL        Mdl
    );