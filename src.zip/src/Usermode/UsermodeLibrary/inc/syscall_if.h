#pragma once

#include "syscall_defs.h"
#include "thread_defs.h"
#include "process_defs.h"
#include "syscall_func.h"