#pragma once

FUNC_DriverEntry                        VolDriverEntry;